<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{psemailvalidation}prestashop>success-redirect_78c9225476e603696fcd82e63c2bb212'] = '¡Verificación exitosa!';
$_MODULE['<{psemailvalidation}prestashop>success-redirect_80242fdbfeea36eb6ad3dfa66925409e'] = 'Serás redirigido al';
$_MODULE['<{psemailvalidation}prestashop>success-redirect_177627f91af678a9b03e993f1a91917f'] = 'checkout';
$_MODULE['<{psemailvalidation}prestashop>success-redirect_2d5a4eebfaf348c097ce2509288ef568'] = 'en';
$_MODULE['<{psemailvalidation}prestashop>email-sent-to_d9497421d025b5de332be820bf7f97e8'] = 'Necesitamos validar tu e-mail';
$_MODULE['<{psemailvalidation}prestashop>email-sent-to_f52a84afdbcae6265ef839a6d0e41745'] = 'Enviamos un enlace de verificación a';
$_MODULE['<{psemailvalidation}prestashop>email-sent-to_9b6ee66bfb9733b0d07df20af9981159'] = 'Puede que nuestro mensaje llegue a tu carpeta de spam/correo no deseado.';
$_MODULE['<{psemailvalidation}prestashop>failure_9feb2b2dff95623a3dd42f5f361e44a4'] = 'Oops...';
$_MODULE['<{psemailvalidation}prestashop>failure_282cd9c5a163476c35320b7ad63373fb'] = 'Tuvimos un problema mientras tratabamos de registrarte.';
$_MODULE['<{psemailvalidation}prestashop>failure_390a3537462a6613413d72d4d49cb38c'] = 'Por favor, contáctate con nuestro soporte.';
$_MODULE['<{psemailvalidation}prestashop>activate_7af4a7d5161a7b8590d9b606608009e1'] = 'Parece que el token que tienes no es válido.';
$_MODULE['<{psemailvalidation}prestashop>activate_649787cc118e94a003c4d2e9afe7dec6'] = 'Tu token ha expirado.';
$_MODULE['<{psemailvalidation}prestashop>activate_9442a6f2caf706f00c774413d989b058'] = 'Surgió un problema activando tu cuenta.';
$_MODULE['<{psemailvalidation}prestashop>activate_7a6be0a1992808b9bd4b381e3140ab31'] = '¡Verificación exitosa! Usá tus credenciales la proxima vez que iniciés sesión.';

<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{psemailvalidation}prestashop>success-redirect_78c9225476e603696fcd82e63c2bb212'] = '¡Verificación exitosa!';
$_MODULE['<{psemailvalidation}prestashop>success-redirect_80242fdbfeea36eb6ad3dfa66925409e'] = 'Serás redirigido al';
$_MODULE['<{psemailvalidation}prestashop>success-redirect_177627f91af678a9b03e993f1a91917f'] = 'checkout';
$_MODULE['<{psemailvalidation}prestashop>success-redirect_2d5a4eebfaf348c097ce2509288ef568'] = 'en';
$_MODULE['<{psemailvalidation}prestashop>email-sent-to_90668cbb85d609369d97ae274d18470d'] = 'Validar E-mail';
$_MODULE['<{psemailvalidation}prestashop>email-sent-to_30cc8b830e0c06577c7c9cc65be0fb60'] = 'Enviamos un enlace de verificación a';
$_MODULE['<{psemailvalidation}prestashop>email-sent-to_9b6ee66bfb9733b0d07df20af9981159'] = 'Puede que nuestro mensaje llegue a tu carpeta de spam/correo no deseado.';
$_MODULE['<{psemailvalidation}prestashop>failure_9feb2b2dff95623a3dd42f5f361e44a4'] = 'Oops...';
$_MODULE['<{psemailvalidation}prestashop>failure_9442a6f2caf706f00c774413d989b058'] = 'Ocurrió un problema activando tu cuenta.';
$_MODULE['<{psemailvalidation}prestashop>failure_dbbab6d2b5a2a25678d27a530e6fbf5d'] = 'Si estas seguro de que usaste el link que te enviamos, ponte en contacto con nuestro soporte.';
$_MODULE['<{psemailvalidation}prestashop>activate_7a6be0a1992808b9bd4b381e3140ab31'] = '¡Verificación exitosa! Usá tus credenciales la proxima vez que iniciés sesión.';

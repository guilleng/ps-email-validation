<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{psemailvalidation}prestashop>psemailvalidation_6fab24fa97340314018307caa46ec901'] = 'Validar registros por email';
$_MODULE['<{psemailvalidation}prestashop>psemailvalidation_9bd8408025a31baf2fcd8073400f7858'] = 'Los usuarios deberán verificar su email para acceder a su cuenta. Al activarla, inician sesión automáticamente, se restaura su carrito y son redirigidos al checkout.';
$_MODULE['<{psemailvalidation}prestashop>psemailvalidation_562718698659eab689fb0e81307b3724'] = 'Validar e-mail';
